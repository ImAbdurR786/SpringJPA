package com.cg.collection.pp.service;

import com.cg.collection.pp.bean.Customer;
import com.cg.collection.pp.bean.Transaction;
import com.cg.collection.pp.dao.BankDAOImpl;

import java.util.HashMap;

public class BankServiceImpl implements IBankService{
    BankDAOImpl bankDao = new BankDAOImpl();
    
    @Override
    public long createAccount(Customer customer, Transaction transaction) {
      return bankDao.createAccount(customer,transaction);
    }

    @Override
    public int showBalance(long acntNo, int pinNo) {
    if(bankDao.getHashMap().containsKey(acntNo)){
    if(bankDao.getHashMap().get(acntNo).getPin()==pinNo){
    return bankDao.getHashMap().get(acntNo).getBalance();
    }else return -1;
    }else return 0;
    }

    @Override
    public int  depositeMoney(long accountNumber, int amountDeposite, Transaction transaction) {
    int totalbal = bankDao.getHashMap().get(accountNumber).getBalance() + amountDeposite;
    return bankDao.depositeMoney(accountNumber,totalbal,transaction);
    }

    @Override
    public int withdrawMoney(long accountNumbr, int amountWithdraw, Transaction transaction) {
        if(bankDao.getHashMap().get(accountNumbr).getBalance()>amountWithdraw){
        int totalbal = bankDao.getHashMap().get(accountNumbr).getBalance() - amountWithdraw;
            return bankDao.withdrawMoney(accountNumbr,totalbal,transaction);
        }else
            return -1;
    }

    @Override
    public int fundTransfer(long fromaccountNo, long toaccountNo, int moneyTransfer, Transaction transaction, Transaction transaction1) {
      
     if(bankDao.getHashMap().get(fromaccountNo).getBalance()>moneyTransfer){
     int totalWithdraw = bankDao.getHashMap().get(fromaccountNo).getBalance() - moneyTransfer;
     int totalDeposite = bankDao.getHashMap().get(toaccountNo).getBalance() + moneyTransfer;
     bankDao.fundTransfer(fromaccountNo,toaccountNo,totalWithdraw,totalDeposite,transaction,transaction1);
     return 1;}
     else return -1;
    }

    @Override
    public HashMap<Long, Transaction> printTransaction(long acountNo) {
		return bankDao.printTransaction(acountNo);
	}
  	
}
