/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.collection.pp.service;

import com.cg.collection.pp.bean.Customer;
import com.cg.collection.pp.bean.Transaction;
import java.util.HashMap;

/**
 *
 * @author Raja
 */
public interface IBankService {
     public long createAccount(Customer customer, Transaction transaction);
    public int showBalance(long acntNo, int pinNo);
    public int depositeMoney(long accountNumber, int totalbal, Transaction transaction);
    public int withdrawMoney(long accountNumbr, int totalbal, Transaction transaction);
   public int fundTransfer(long fromaccountNo, long toaccountNo, int moneyTransfer, Transaction transaction, Transaction transaction1);
    public HashMap<Long, Transaction> printTransaction(long acountNo);
}
