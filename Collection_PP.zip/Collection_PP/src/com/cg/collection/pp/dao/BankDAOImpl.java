/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.collection.pp.dao;

import com.cg.collection.pp.bean.Customer;
import com.cg.collection.pp.bean.Transaction;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class BankDAOImpl implements IBankDAO{

	HashMap<Long, Customer> hashMap = new HashMap<Long, Customer>();
	HashMap<Long, Transaction> transactionHashMap = new HashMap<Long, Transaction>();
	
        @Override
	public long createAccount(Customer customer, Transaction transaction) {
		hashMap.put(customer.getAccountNo(), customer);
		transactionHashMap.put(transaction.getId(), transaction);
		return customer.getAccountNo();
	}

        @Override
	public HashMap<Long, Customer> getHashMap() {
		return hashMap;
	}

        @Override
	public int depositeMoney(long accountNumber, int totalbal, Transaction transaction) {
		hashMap.get(accountNumber).setBalance(totalbal);
		transactionHashMap.put(transaction.getId(), transaction);
		return hashMap.get(accountNumber).getBalance();
	}

        @Override
	public int withdrawMoney(long accountNumbr, int totalbal, Transaction transaction) {
		hashMap.get(accountNumbr).setBalance(totalbal);
		transactionHashMap.put(transaction.getId(), transaction);
		return hashMap.get(accountNumbr).getBalance();
	}

        @Override
	public void fundTransfer(long fromaccountNo, long toaccountNo, int totalWithdraw, int totalDeposite,
			Transaction transaction, Transaction transaction1) {
		hashMap.get(fromaccountNo).setBalance(totalWithdraw);
		hashMap.get(toaccountNo).setBalance(totalDeposite);
		transactionHashMap.put(transaction.getId(), transaction);
		transactionHashMap.put(transaction1.getId(), transaction1);
	}
        

        @Override
	public HashMap<Long, Transaction> printTransaction(long acountNo) {
            HashMap<Long, Transaction> trans = new HashMap<Long, Transaction>();
            Set<Long> keys = transactionHashMap.keySet();
		Iterator<Long> itr = keys.iterator();
		Long key;
		while (itr.hasNext()) {
			key = itr.next();
                        System.out.println(transactionHashMap.get(key).getType());
			if (transactionHashMap.get(key).getAccountNo() == acountNo) {
                            trans.put(key, transactionHashMap.get(key));
                            break;
			}
                }
		return trans;
	}
}
