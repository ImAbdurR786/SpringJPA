package com.cg.collection.pp.ui;

import com.cg.collection.pp.service.BankService;
import com.cg.collection.pp.bean.Customer;
import com.cg.collection.pp.exception.UserDefineException;
import java.util.Scanner;

public class BankMenu {

    public static void main(String[] args) {
    
        Scanner scanner = new Scanner(System.in);
        Customer customer;
        BankService bankService = new BankService();
        long accountNo;
        do{
        System.out.println("***************************************************************************");
		System.out.println("1. Create Account \n 2. Show Balance \n 3. Deposite "
				+ "\n 4. Withdraw \n 5. Fund Transfer \n 6. Print Transcaction \n 7. Exit");
		System.out.println("***************************************************************************");
                System.out.println("Choose any option : ");
        
        int n = scanner.nextInt();
        
        switch(n){
            case 1: 
                double a = Math.random()%100;            // Creating a random number
		accountNo =(long)(a*1234567898);    // Mutliplying with a dummy no. to get dummy account no.
                String name;
		do{
                    System.out.println("Enter the Name");
                    name = scanner.next();
                }while(!bankService.isNameValid(name));
                String  number;
		do{System.out.println("Enter the Number");
		number = scanner.next();}while(!bankService.isValidNumber(number));
		try{
		Long.parseLong(number);                                                                                                             
		if(number.length() == 10) {
		System.out.println("Enter the Pin.");
		int pin = scanner.nextInt();
		int balance;
                do{System.out.println("Enter the Balance to be deposit(should be greater than 999).");
		balance = scanner.nextInt();
                }while(balance<1000);
               
		customer = new Customer(name,number,pin,balance); 
		customer.setAccountNo(accountNo);
                customer.setTrans("Account Created with "+balance);
                long accountNum = bankService.createAccount(customer);
		System.out.println("Your account is Created Successfully");
		System.out.println("Account number is :" + accountNum);
		}
		else
		try{
                    throw new UserDefineException("Number should be of 10 digits");
                }catch(UserDefineException exc){
                    System.out.println(exc);
                }
                    }catch(NumberFormatException e ) {
                        System.out.println("Number should contain only digits");}
                break;	
        
            case 2: System.out.println("Enter the Account Number");
                    long acntNo = scanner.nextLong();
                    System.out.println("Enter the pin");
                    int pinNo= scanner.nextInt();
                    int balnc = bankService.showBalance(acntNo,pinNo);
        switch (balnc) {
            case 0:
                System.out.println("No such Account number Exists");
                break;
            case -1:
                System.out.println("Your Pin is wrong");
                break;
            default:
                System.out.println("Your balance is "+balnc);
                break;
        }
                break;
                
                
            case 3: System.out.println("Enter the Account Number");
                    long accountNumber = scanner.nextLong();
                    System.out.println("Enter the Pin");
                    int pinNum = scanner.nextInt();
                    int bal =  bankService.showBalance(accountNumber, pinNum);
        switch (bal) {
            case 0:
                System.out.println("No such Account number Exists");
                break;
            case -1:
                System.out.println("Your Pin is wrong");
                break;
            default:
                System.out.println("Current balance is "+bal);
                int amountDeposite;
                do{ System.out.println("Enter the Amount to be Deposited");
                amountDeposite = scanner.nextInt();}while(amountDeposite<0);
                String trans ="Amount Deposited: "+amountDeposite;
                int baln = bankService.depositeMoney(accountNumber,amountDeposite,trans);
                System.out.println("Successfully Deposited \n Your updated Balance is "+ baln);
                break;
        }
                break;
      
                
            case 4: System.out.println("Enter the Account Number");
                    long accountNumbr = scanner.nextLong();
                    System.out.println("Enter the Pin");
                    int pinNumb = scanner.nextInt();
                   int balan =  bankService.showBalance(accountNumbr, pinNumb);
        switch (balan) {
            case 0:
                System.out.println("No such Account number Exists");
                break;
            case -1:
                System.out.println("Your Pin is wrong");
                break;
            default:
                System.out.println("Current balance is "+balan);
                int amountWithdraw;
                do{ System.out.println("Enter the Amount to Withdraw");
                amountWithdraw = scanner.nextInt();}while(amountWithdraw<0);
                 String trans ="Amount Withdraw: "+amountWithdraw;
                 int balnce = bankService.withdrawMoney(accountNumbr,amountWithdraw,trans);
                if(balnce==-1){
                    System.out.println("Insufficient Balance");}
                else{
                System.out.println("Successfully Withdraw \n Your updated Balance is "+ balnce);}
                break;
        }
                break;
                
            case 5: 
                System.out.println("Enter your Account Number");
                long fromaccountNo = scanner.nextLong();
                System.out.println("Enter the pinNo");
                int pinN = scanner.nextInt();
             int check =  bankService.showBalance(fromaccountNo, pinN);
        switch (check) {
            case 0:
                System.out.println("No such Account number Exists");
                break;
            case -1:
                System.out.println("Your Pin is wrong");
                break;
            default:
                long toaccountNo;
               do{ System.out.println("Enter the Account Number whom you want to transfer the money");
                toaccountNo = scanner.nextLong();}while(!bankService.isAccountValid(toaccountNo));
                if(fromaccountNo==toaccountNo){
                    System.out.println("Both Account Number must be different");}
                else{
                    System.out.println("Enter the amount to transfer");
                    int moneyTransfer = scanner.nextInt();
                    String trans1 =moneyTransfer +" Transfer to: "+toaccountNo +" from "+ fromaccountNo;
                    String trans2 =moneyTransfer +" Recieve from: "+fromaccountNo +" to "+ toaccountNo;
                    int totalbalnc = bankService.fundTransfer(fromaccountNo,toaccountNo,moneyTransfer,trans1,trans2);
                    if(totalbalnc==-1){
                        System.out.println("Fund Transfer Fails(Insufficient Balance)");}
                    else{
                        System.out.println("Fund Transfer Successful");
                    }
                }
        }
                break;
                
            case 6: System.out.println("Enter the Account number");
                    long acountNo = scanner.nextLong();
                    System.out.println("Enter the Pin Number");
                    int pin = scanner.nextInt();
                    
                   int baln =  bankService.showBalance(acountNo, pin);
        switch (baln) {
            case 0:
                System.out.println("No such Account number Exists");
                break;
            case -1:
                System.out.println("Your Pin is wrong");
                break;
            default:
                System.out.println(bankService.printTransaction(acountNo));    
             }
                    break;
          
            case 7: System.exit(0);
                break;
                
            default: System.out.println("Enter the Valid Choice");
        }
        }while(true);
    }

}
