package com.project.jdbc.exception;

public class NameException {

    public NameException(String message) {
        System.out.println(message);
    }
    
}
