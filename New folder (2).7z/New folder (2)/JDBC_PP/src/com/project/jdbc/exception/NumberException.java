package com.project.jdbc.exception;

public class NumberException {

    public NumberException(String message) {
        System.out.println(message);
    }
  
}
