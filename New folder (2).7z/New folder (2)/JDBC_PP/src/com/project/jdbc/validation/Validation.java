package com.project.jdbc.validation;

import java.util.regex.Pattern;

public class Validation {

    public boolean isNameValid(String name) {
    if(name.length()>4){
     if(Pattern.matches("([A-Z])*([a-z])*", name)){
        return true;
          }else
            return false;
     }else
       return false;
    /*
    if(name.length()>4){
        return Pattern.matches("([A-Z])*([a-z])*", name);
     }else
       return false;
    */
    }

    public boolean isNumberValid(String number) {
        if (number.matches("^[6-9][0-9]{9}$"))
            {
                return true;
            }
        else
         return false;
        
       /* return number.matches("^[6-9][0-9]{9}$");  */
    }
 }