package com.project.jdbc.dao;

import com.project.jdbc.bean.Customer;
import com.project.jdbc.bean.Transaction;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BankDAOImpl implements IBankDAO{

	Connection conn;
	Customer customer;
	Random random = new Random();
	public BankDAOImpl() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String s = "jdbc:oracle:thin:@localhost:1521:xe";
			conn = DriverManager.getConnection(s, "system", "India123");
		} catch (ClassNotFoundException | SQLException ex) {
		}
	}
	
	@Override
	public void createAccount(Customer customer, Transaction transaction) {
		try {
			int transId = random.nextInt(100);
			PreparedStatement prepareStatement = conn.prepareStatement("insert into customerss values(?,?,?,?,?)");
			prepareStatement.setLong(1, customer.getAccountNo());
			prepareStatement.setString(2, customer.getName());
			prepareStatement.setString(3, customer.getNumber());
			prepareStatement.setInt(4, customer.getPin());
			prepareStatement.setInt(5, customer.getBalance());
			prepareStatement.execute();

			ResultSet resultSet = getAccountDetails(customer.getAccountNo());
			while (resultSet.next()) {
				PreparedStatement preparedStatement1 = conn.prepareStatement("insert into Transaction values(?,?,?,?)");
				preparedStatement1.setInt(1, transId);
				preparedStatement1.setString(2, transaction.getType());
				preparedStatement1.setInt(3, transaction.getBalance());
				preparedStatement1.setLong(4, resultSet.getInt(1));
				preparedStatement1.execute();
			}
			
		} catch (SQLException ex) {
		}
	}

	@Override
	public ResultSet getAccountDetails(long accountno) {
		try {
			Statement statement = conn.createStatement();
			ResultSet resultSet = statement.executeQuery("Select * from customerss where AccountNo =" + accountno);
			return resultSet;

		} catch (SQLException ex) {
			return null;
		}
	}
	
	@Override
	public void depositeBalance(long accountNumber, int totalbalance, int deposite, Transaction transaction) {
		try {
			int transId = random.nextInt(100);
			String sql = "update customerss set balance=? where accountno=?";
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setInt(1, totalbalance);
			statement.setLong(2, accountNumber);
			statement.executeUpdate();

			ResultSet resultSet = getAccountDetails(accountNumber);
			while (resultSet.next()) {
				PreparedStatement preparedStatement1 = conn.prepareStatement("insert into Transaction values(?,?,?,?)");
				preparedStatement1.setInt(1, transId);
				preparedStatement1.setString(2, transaction.getType());
				preparedStatement1.setInt(3, transaction.getBalance());
				preparedStatement1.setLong(4, resultSet.getInt(1));
				preparedStatement1.execute();
			}
		} catch (SQLException s) {
		}
	}

	@Override
	public int withdraw(long accountNum, int totalbalance, int withdraw, Transaction transaction) {
		ResultSet resultSet = getAccountDetails(accountNum);
		try {
			int transId = random.nextInt(100);
			String sql = "update customerss set balance=? where accountno=?";
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setInt(1, totalbalance);
			statement.setLong(2, accountNum);
			statement.executeUpdate();
			while (resultSet.next()) {
				PreparedStatement preparedStatement1 = conn.prepareStatement("insert into Transaction values(?,?,?,?)");
				preparedStatement1.setInt(1, transId);
				preparedStatement1.setString(2, transaction.getType());
				preparedStatement1.setInt(3, transaction.getBalance());
				preparedStatement1.setLong(4, resultSet.getInt(1));
				preparedStatement1.executeUpdate();

			}
		} catch (SQLException s) {
			return 0;
		}
		return 1;
	}

	@Override
	public int transfer(Long fromAccountNo, int totalbalance, Long toAccountNo, int totalbalance1,
			Transaction transaction, Transaction transaction1) {
		ResultSet resultSet = getAccountDetails(fromAccountNo);
		ResultSet resultSet1 = getAccountDetails(toAccountNo);
		try {
			int transId = random.nextInt(100);
			int transId1 = random.nextInt(100);
			String sql = "update customerss set balance=? where accountno=?";
			PreparedStatement preparedStatement = conn.prepareStatement(sql);
			preparedStatement.setInt(1, totalbalance);
			preparedStatement.setLong(2, fromAccountNo);
			preparedStatement.executeUpdate();

			PreparedStatement preparedStatement1 = conn.prepareStatement(sql);
			preparedStatement1.setInt(1, totalbalance1);
			preparedStatement1.setLong(2, toAccountNo);
			preparedStatement1.executeUpdate();
			while (resultSet.next()) {
				preparedStatement = conn.prepareStatement("insert into Transaction values(?,?,?,?)");
				preparedStatement1.setInt(1, transId);
				preparedStatement.setString(2, transaction.getType());
				preparedStatement.setInt(3, transaction.getBalance());
				preparedStatement.setLong(4, resultSet.getInt(1));
				preparedStatement.execute();
			}
			while (resultSet1.next()) {
				preparedStatement1 = conn.prepareStatement("insert into Transaction values(?,?,?,?)");
				preparedStatement1.setInt(1, transId1);
				preparedStatement1.setString(2, transaction1.getType());
				preparedStatement1.setInt(3, transaction1.getBalance());
				preparedStatement1.setLong(4, resultSet1.getInt(1));
				preparedStatement1.execute();
			}

		} catch (SQLException s) {
			return 1;
		}
		return 0;
	}

	@Override
	public ResultSet getAccountTransactionDetails(long accountno) {
		try {
			Statement statement = conn.createStatement();
			ResultSet resultSet = statement.executeQuery("Select * from Transaction where accountno =" + accountno);
			return resultSet;

		} catch (SQLException ex) {
			return null;
		}
	}

	@Override
	public ResultSet printTransaction(long transAccNo) {
		ResultSet resultSet = getAccountTransactionDetails(transAccNo);
		return resultSet;
	}
}
