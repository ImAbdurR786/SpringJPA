package com.cg.collection.pp.ui;

import com.cg.collection.pp.service.BankServiceImpl;
import com.cg.collection.pp.bean.Customer;
import com.cg.collection.pp.bean.Transaction;
import com.cg.collection.pp.exception.UserDefineException;
import com.cg.collection.pp.validation.Validation;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class BankMenu {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		Customer customer;
		BankServiceImpl bankService = new BankServiceImpl();
                Validation validation = new Validation();
		long accountNo;
		do {
			System.out.println("***************************************************************************");
			System.out.println("1. Create Account \n 2. Show Balance \n 3. Deposite "
					+ "\n 4. Withdraw \n 5. Fund Transfer \n 6. Print Transcaction \n 7. Exit");
			System.out.println("***************************************************************************");
			System.out.println("Choose any option : ");

			int n = scanner.nextInt();

			switch (n) {
			case 1:
				double a = Math.random() % 100; // Creating a random number
				accountNo = (long) (a * 1234567898); // Mutliplying with a dummy no. to get dummy account no.
				double id = Math.random() % 100; // Creating a random number
				Long ids = (long) (id * 12345);
				String name;
				do {
					System.out.println("Enter the Name");
					name = scanner.next();
				} while (!validation.isNameValid(name));
				String number;
				do {
					System.out.println("Enter the Number");
					number = scanner.next();
				} while (!validation.isValidNumber(number));
				try {
					Long.parseLong(number);
					if (number.length() == 10) {
						System.out.println("Enter the Pin.");
						int pin = scanner.nextInt();
						int balance;
						do {
							System.out.println("Enter the Balance to be deposit(should be greater than 999).");
							balance = scanner.nextInt();
						} while (balance < 1000);

						customer = new Customer(name, number, pin, balance);
						customer.setAccountNo(accountNo);
						Transaction transaction = new Transaction("Account Created", balance);
						transaction.setId(ids);
                                                transaction.setAccountNo(accountNo);
						long accountNum = bankService.createAccount(customer, transaction);
						System.out.println("Your account is Created Successfully");
						System.out.println("Account number is :" + accountNum);
					} else
						try {
							throw new UserDefineException("Number should be of 10 digits");
						} catch (UserDefineException exc) {
							System.out.println(exc);
						}
				} catch (NumberFormatException e) {
					System.out.println("Number should contain only digits");
				}
				break;

			case 2:
				System.out.println("Enter the Account Number");
				long acntNo = scanner.nextLong();
				System.out.println("Enter the pin");
				int pinNo = scanner.nextInt();
				int balnc = bankService.showBalance(acntNo, pinNo);
				switch (balnc) {
				case 0:
					System.out.println("No such Account number Exists");
					break;
				case -1:
					System.out.println("Your Pin is wrong");
					break;
				default:
					System.out.println("Your balance is " + balnc);
					break;
				}
				break;

			case 3:
				double i = Math.random() % 100; // Creating a random number
				Long ia = (long) (i * 12345);
				System.out.println("Enter the Account Number");
				long accountNumber = scanner.nextLong();
				System.out.println("Enter the Pin");
				int pinNum = scanner.nextInt();
				int bal = bankService.showBalance(accountNumber, pinNum);
				switch (bal) {
				case 0:
					System.out.println("No such Account number Exists");
					break;
				case -1:
					System.out.println("Your Pin is wrong");
					break;
				default:
					System.out.println("Current balance is " + bal);
					int amountDeposite;
					do {
						System.out.println("Enter the Amount to be Deposited");
						amountDeposite = scanner.nextInt();
					} while (amountDeposite < 0);
					
					Transaction transactions = new Transaction("Amount Deposited", amountDeposite);
					transactions.setId(ia);
                                        transactions.setAccountNo(accountNumber);
					int baln = bankService.depositeMoney(accountNumber, amountDeposite,transactions);
					System.out.println("Successfully Deposited \n Your updated Balance is " + baln);
					break;
				}
				break;

			case 4:
				double x = Math.random() % 100; // Creating a random number
				Long ix = (long) (x * 12345);
                                System.out.println("Enter the Account Number");
				long accountNumbr = scanner.nextLong();
				System.out.println("Enter the Pin");
				int pinNumb = scanner.nextInt();
				int balan = bankService.showBalance(accountNumbr, pinNumb);
				switch (balan) {
				case 0:
					System.out.println("No such Account number Exists");
					break;
				case -1:
					System.out.println("Your Pin is wrong");
					break;
				default:
					System.out.println("Current balance is " + balan);
					int amountWithdraw;
					do {
						System.out.println("Enter the Amount to Withdraw");
						amountWithdraw = scanner.nextInt();
					} while (amountWithdraw < 0);
					Transaction transaction3 = new Transaction("Amount Withdraw", amountWithdraw);
					transaction3.setId(ix);
                                        transaction3.setAccountNo(accountNumbr);
					int balnce = bankService.withdrawMoney(accountNumbr, amountWithdraw,transaction3);
					if (balnce == -1) {
						System.out.println("Insufficient Balance");
					} else {
						System.out.println("Successfully Withdraw \n Your updated Balance is " + balnce);
					}
					break;
				}
				break;

			case 5:
				double v = Math.random() % 100; // Creating a random number
				Long iv = (long) (v * 12345);
                                double u = Math.random() % 100; // Creating a random number
				Long iu = (long) (u * 12345);
                                System.out.println("Enter your Account Number");
				long fromaccountNo = scanner.nextLong();
				System.out.println("Enter the pinNo");
				int pinN = scanner.nextInt();
				int check = bankService.showBalance(fromaccountNo, pinN);
				switch (check) {
				case 0:
					System.out.println("No such Account number Exists");
					break;
				case -1:
					System.out.println("Your Pin is wrong");
					break;
				default:
					long toaccountNo;
//					do {
						System.out.println("Enter the Account Number whom you want to transfer the money");
						toaccountNo = scanner.nextLong();
//					} while (!validation.isAccountValid(toaccountNo));
					if (fromaccountNo == toaccountNo) {
						System.out.println("Both Account Number must be different");
					} else {
						System.out.println("Enter the amount to transfer");
						int moneyTransfer = scanner.nextInt();
						Transaction transaction1 = new Transaction("Money Transfer", moneyTransfer);
						transaction1.setId(iv);
                                                transaction1.setAccountNo(fromaccountNo);
                                                Transaction transaction2 = new Transaction("Money Receive", moneyTransfer);
						transaction2.setId(iu);
                                                transaction2.setAccountNo(toaccountNo);
                                                int totalbalnc = bankService.fundTransfer(fromaccountNo, toaccountNo, moneyTransfer,transaction1,transaction2);
						if (totalbalnc == -1) {
							System.out.println("Fund Transfer Fails(Insufficient Balance)");
						} else {
							System.out.println("Fund Transfer Successful");
						}
					}
				}
				break;

			case 6:
				System.out.println("Enter the Account number");
				long acountNo = scanner.nextLong();
				System.out.println("Enter the Pin Number");
				int pin = scanner.nextInt();

				int baln = bankService.showBalance(acountNo, pin);
				switch (baln) {
				case 0:
					System.out.println("No such Account number Exists");
					break;
				case -1:
					System.out.println("Your Pin is wrong");
					break;
				default:
					
					
//					 HashMap<Long,Transaction> printTrans= bankService.printTransaction(acountNo);
//					 Set<Long> keys=printTrans.keySet();
//                                         Iterator<Long> itr=keys.iterator();
//					 Long key;
//					 System.out.println("Transaction Id"+"     "+"Transaction Type"+ "   " + "Transaction Amount");
//                                         while(itr.hasNext())
//                                            {
//                                	       key= itr.next();
//                                               System.out.println(printTrans.get(key).getId()+"    "+
//                                                       printTrans.get(key).getType() + "    " +
//                                                       printTrans.get(key).getBalance());
//					      
//					    }
					
					
					 HashMap<Long,Transaction> printTrans= bankService.printTransaction(acountNo);
					 Set<Long> keys=printTrans.keySet();
                                         Iterator<Long> itr=keys.iterator();
					 Long key;
					 System.out.println("Transaction Id"+"     "+"Transaction Type"+ "   " + "Transaction Amount");
                                         while(itr.hasNext())
                                            {
                                	       key= itr.next();
                                               System.out.println(printTrans.get(key).getId()+"    "+
                                                       printTrans.get(key).getType() + "    " +
                                                       printTrans.get(key).getBalance());
					      
					    }
				}
				break;

			case 7:
				System.exit(0);
				break;

			default:
				System.out.println("Enter the Valid Choice");
			}
		} while (true);
	}

}
