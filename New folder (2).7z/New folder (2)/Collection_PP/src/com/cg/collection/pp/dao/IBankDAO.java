/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.collection.pp.dao;

import com.cg.collection.pp.bean.Customer;
import com.cg.collection.pp.bean.Transaction;
import java.util.HashMap;

/**
 *
 * @author Raja
 */
public interface IBankDAO {
    public long createAccount(Customer customer, Transaction transaction);
    public HashMap<Long, Customer> getHashMap();
    public int depositeMoney(long accountNumber, int totalbal, Transaction transaction);
    public int withdrawMoney(long accountNumbr, int totalbal, Transaction transaction);
    public void fundTransfer(long fromaccountNo, long toaccountNo, int totalWithdraw, int totalDeposite,
			Transaction transaction, Transaction transaction1);
    public HashMap<Long,Transaction> printTransaction(long acountNo);
    
}
