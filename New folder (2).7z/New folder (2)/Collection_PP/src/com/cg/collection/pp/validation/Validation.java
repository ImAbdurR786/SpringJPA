/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.collection.pp.validation;

import com.cg.collection.pp.dao.BankDAOImpl;
import java.util.regex.Pattern;
public class Validation {

    BankDAOImpl bankDao = new BankDAOImpl();
  
    public boolean isNameValid(String name){
       if(name.length()>4){
            if(Pattern.matches("([A-Z])*([a-z])*", name)){
            return true;
            }else{
            return false;
            }
          }
      else
       return false;
    }
    
    public boolean isAccountValid(long toaccountNo) {
    if(bankDao.getHashMap().containsKey(toaccountNo)){
    return true;}
    else
    return false;    
    }

    public boolean isValidNumber(String number) {
    return true;
    }

    

}
