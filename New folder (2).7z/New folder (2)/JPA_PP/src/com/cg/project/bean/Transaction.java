package com.cg.project.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
@Table(name="Transaction")
public class Transaction {
    @Id
    @Column(name="Trans_ID",length=20)
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    
    @Column(name="Trans_Type",length=20)
    private String type;
    
    @Column(name="Trans_balance",length=20)
    private int balance;
    
    @ManyToOne
    private Customer customer;
   
    public Transaction(String type, int balance) {
        this.type = type;
        this.balance = balance;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

}
