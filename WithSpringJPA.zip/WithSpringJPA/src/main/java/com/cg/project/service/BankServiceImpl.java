package com.cg.project.service;

import com.cg.project.bean.Customer;
import com.cg.project.bean.Transaction;
import java.util.List;
import java.util.regex.Pattern;

@Service("service")
public class BankServiceImpl implements BankService{
        @Autowired
	private BankDAO bankDao;
    //BankDAO bankDao = new BankDAO();
   
        @Override
        public void createAccount(Customer customer) {
              //  bankDao.beginTransaction();
                bankDao.createAccount(customer);
               // bankDao.commitTransaction();
    }

    public boolean contain(Long accountNo) {
        return  bankDao.conatin(accountNo);
    }

    public boolean checkPin(int pin, Long accountNo) {
        return bankDao.checkPin(pin,accountNo);
    }
    
    @Override
    public int showbalance(Long accountNo) {
     return bankDao.showbalance(accountNo);
    }

    @Override
    public void depositeBalance(long accountNumber, int deposite,Transaction transaction) {
             //   bankDao.beginTransaction();
                Customer customer = bankDao.getCustomerByAccountNo(accountNumber);
                customer.setBalance(customer.getBalance()+deposite);
                transaction.setCustomer(customer);
                bankDao.depositeBalance(customer,transaction);
              //  bankDao.commitTransaction();
                
    }

    @Override
    public int withdraw(long accountNu, int withdraw, Transaction transaction) {
          //  bankDao.beginTransaction();
            Customer customer = bankDao.getCustomerByAccountNo(accountNu);
            if(customer.getBalance()> withdraw){
               customer.setBalance(customer.getBalance()-withdraw);
               transaction.setCustomer(customer);
               bankDao.withdrawBalance(customer,transaction);
          //     bankDao.commitTransaction();
            return 1;
            }else{
            return -1;
            }
    }

    @Override
    public int fundTransfer(Long fromAcc, Long toAcc, int money, Transaction transaction1, Transaction transaction2) {
        Customer customer1 = bankDao.getCustomerByAccountNo(fromAcc);
        if(customer1.getBalance()>money){
            Customer customer2 = bankDao.getCustomerByAccountNo(toAcc);
            transaction1.setCustomer(customer1);
            transaction2.setCustomer(customer2);
            customer2.setBalance(customer2.getBalance()+money);
            customer1.setBalance(customer1.getBalance()-money);
            bankDao.fundTransfer(customer1,customer2,transaction1,transaction2);
         return 1;
        }else{
        return -1;}
    }

    @Override
    public List<Transaction> printTransaction(long transAccNo) {
     return bankDao.printTransaction(transAccNo); 
    }   

    public boolean isNameValid(String name) {
    if(name.length()>4){
     if(Pattern.matches("([A-Z])*([a-z])*", name)){
        return true;
          }else
            return false;
     }else
       return false;
    }

    public boolean isNumberValid(String number) {
        if (number.matches("^[6-9][0-9]{9}$"))
            {
                return true;
            }
        else
            return false;
  }


}