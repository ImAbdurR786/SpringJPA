package com.cg.project.dao;

import com.cg.project.bean.Customer;
import com.cg.project.bean.Transaction;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;

@Repository("dao")
@Transactional
public class BankDAOImpl implements BankDAO{
    
        
        @PersistenceContext
	private EntityManager entityManager;

//	public void setEntityManager(EntityManager entityManager) {
//		this.entityManager = entityManager;
//	}
        
        public Customer getCustomerByAccountNo(Long accountNum){
          Customer customer = entityManager.find(Customer.class, accountNum);
          return customer;
        }
        
        @Override
        public void createAccount(Customer customer) {
                entityManager.persist(customer);
        }
 
        @Override
        public int showbalance(Long showaccountNo) {
        Customer customer = entityManager.find(Customer.class, showaccountNo);
        return customer.getBalance();
        }
    
       @Override
        public void depositeBalance(Customer customer, Transaction transaction) {
         entityManager.merge(customer);
         entityManager.merge(transaction);
        }
    
        @Override
       public void withdrawBalance(Customer customer, Transaction transaction) {
        entityManager.merge(customer);
        entityManager.merge(transaction);
       }
       
       @Override
        public void fundTransfer(Customer customer1, Customer customer2, Transaction transaction1, Transaction transaction2) {
         entityManager.merge(customer1);
         entityManager.merge(customer2);
         entityManager.merge(transaction1);
         entityManager.merge(transaction2);
        }

   
        @Override
        public List<Transaction> printTransaction(long transAccNo) {
        Query query = entityManager.createQuery("select c from Transaction c where c.customer.accountNo=" + transAccNo);
        return query.getResultList();
        }
   
    public boolean conatin(Long accountNo) {
        Customer customer = entityManager.find(Customer.class,accountNo);
        if(customer==null)
            return false;
        else
           return true;
    }

    public boolean checkPin(int pin, Long accountNo) {
    Customer customer = entityManager.find(Customer.class, accountNo);
    if(customer.getPin() == pin){
    return true;}
    else
        return false;
    }   
  
}
